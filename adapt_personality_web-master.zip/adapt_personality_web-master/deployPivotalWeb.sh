cd /Users/sujoyghosal/Desktop/apps/ADAPT/PersonalityWeb
rm -rf node_modules
cf login -a https://api.run.pivotal.io -u sujoy.ghosal@gmail.com -p Kolkata_1
cf push PersonalityWeb
